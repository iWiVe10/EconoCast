## PROJECT: ECONOCAST

## Instalación de Paquetes
pip install -r requirements.txt
